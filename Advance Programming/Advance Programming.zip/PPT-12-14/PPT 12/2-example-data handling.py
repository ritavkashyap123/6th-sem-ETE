age=input('Enter your age:')
f=open("data.txt", 'w')
f.write(age)
f.close()
