f=open("data.txt", 'r')
print(f.read())
f.close()

