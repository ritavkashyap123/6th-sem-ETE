f=open('hello.txt', mode='r')
if f:
    print("file successfully opened")

