f=open("hello.txt",mode='r')
print(f.readable())
print (f.writable())
f.close()