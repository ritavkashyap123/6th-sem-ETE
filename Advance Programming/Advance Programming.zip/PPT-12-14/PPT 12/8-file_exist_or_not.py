import os
print(os.path.isfile("Hello.txt"))

