f=open('Hello.txt', 'r')
#operations
f.close()