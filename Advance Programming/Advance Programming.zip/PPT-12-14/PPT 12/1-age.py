age=int(input('Enter your age:'))
if age>18:
    print("eligible for voting card")


